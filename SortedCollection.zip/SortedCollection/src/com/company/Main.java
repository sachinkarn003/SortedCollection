package com.company;

import java.util.Map;

public class Main {
     private static StockList stockList = new StockList();
    public static void main(String[] args) {
        StockItem item = new StockItem("bread",0.86,100);
        stockList.addStock(item);

        item = new StockItem("Cake",12.50,2);
        stockList.addStock(item);

        item = new StockItem("Car",62.0,2);
        stockList.addStock(item);

        item = new StockItem("Chair",25.5,9);
        stockList.addStock(item);

        item = new StockItem("Cup",100.5,50);
        stockList.addStock(item);

        item = new StockItem("Door",5.6,7);
        stockList.addStock(item);

        item = new StockItem("Juice",10.9,5);
        stockList.addStock(item);

        item = new StockItem("Phone",50.50,50);
        stockList.addStock(item);

        item = new StockItem("towel",5.0,2);
        stockList.addStock(item);

        item = new StockItem("vase",300.5,5);
        stockList.addStock(item);

        System.out.println(stockList);

        for (String s: stockList.Item().keySet()) {
            System.out.println(s);
        }


            Basket spiderBasket = new Basket("spider");
            sellItem(spiderBasket,"Car",1);
            System.out.println(spiderBasket);

            sellItem(spiderBasket,"Car",1);
            System.out.println(spiderBasket);

            sellItem(spiderBasket,"Car",1);
            sellItem(spiderBasket,"milk",5);
            System.out.println(spiderBasket);


            sellItem(spiderBasket,"Juice",4);
            sellItem(spiderBasket,"Cup",12);
            sellItem(spiderBasket,"bread",1);
            System.out.println(spiderBasket);

            System.out.println(stockList);

//            item = new StockItem("pen",1.12);
//            stockList.Item().put(item.getName(),item);

        stockList.Item().get("Car").adJustStock(2000);
        System.out.println(stockList);

    }

    public static int sellItem (Basket basket, String item, int quantity){
        StockItem stockItem = stockList.get(item);
        if (stockItem == null){
            System.out.println("We don't sell "+item);
            return 0;
        }

//        if (stockList.sellStock(item,quantity)!=0){
//            basket.addToBasket(stockItem,quantity);
//            return quantity;
//        }

        if (stockList.reservedStock(item,quantity)!=0){
            basket.addToBasket(stockItem,quantity);
            return quantity;
        }
        return 0;
    }

    public static int removeItem (Basket basket, String item, int quantity){
        //retrieve the item from stock
        StockItem stockItem = stockList.get(item);
        if (stockItem == null){
            System.out.println("We don't sell "+item);
            return 0;
        }

        if (basket.removeFromBasket(stockItem,quantity)!=0){
           return stockList.unreservedStock(item,quantity);
        }
        return 0;
    }

    public static void checkOut(Basket basket){
        for (Map.Entry<StockItem,Integer> Item : basket.Item().entrySet()){
            stockList.sellStock(Item.getKey().getName(),Item.getValue());
        }
        basket.clearBasket();
    }
}
